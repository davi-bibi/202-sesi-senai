package POO_004;
public abstract class Pessoa {

    private String nome;
    private String cpf;
    private int idade;
    private String telefone;
    
    public   Pessoa (){

    }
    

   
    public  Pessoa(String nome, String cpf, String telefone, int idade) {
        this.nome = nome;
        this.cpf = cpf;
        this.telefone = telefone;
        this.idade = idade;
    }
    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getCpf() {
        return cpf;
    }

    public void setCpf(String cpf) {
        this.cpf = cpf;
    }

    public String getTelefone() {
        return telefone;
    }

    public void setTelefone(String telefone) {
        this.telefone = telefone;
    }

    public int getidade() {
        return idade;
    }

    public void setidade(int idade) {
        this.idade = idade;
    }
public abstract void cadastrar();
public abstract void exibirDados();

    public static void main(String[] args) {
        Main.main(args);
    }
}