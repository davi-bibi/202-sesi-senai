package POO_004;

public class cliente extends Pessoa {
    private String codigo_cliente;
    private String endereco;

    public cliente(String nome, int idade, String cpf, String telefone,
                   String codigo_cliente, String endereco) {
        super(nome, cpf, telefone, idade);
        this.codigo_cliente = codigo_cliente;
        this.endereco = endereco;
    }

    public String getcodigo_cliente() {
        return codigo_cliente;
    }

    public void setcodigo_cliente(String codigo_cliente) {
        this.codigo_cliente = codigo_cliente;
    }

    public String getendereco() {
        return endereco;
    }

    public void setendereco(String endereco) {
        this.endereco = endereco;
    }

    @Override
    public void cadastrar() {
        exibirDados();
    }

    @Override
    public void exibirDados() {
        System.out.printf("DADOS DO CLIENTE%n"
                + "nome: %s%nidade: %d%nCPF: %s%ntelefone: %s%n"
                + "código do cliente: %s%nendereço: %s%n",
                getNome(), getidade(), getCpf(), getTelefone(),
                codigo_cliente, endereco);
    }
}
