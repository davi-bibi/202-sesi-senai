package POO_004;

public class animal {
}
