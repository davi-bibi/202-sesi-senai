package POO_004;

public class veterinario extends Pessoa {
    private String crmv;
    private String especialidade;

    public veterinario(String nome, double peso, Strin raca) {
        super(nome, peso, raca);
        this.crmv = crmv;
        this.especialidade = especialidade;
    }

    public String getcrmv() {
        return crmv;
    }

    public void setcrmv(String crmv) {
        this.crmv = crmv;
    }

    public String getespecialidade() {
        return especialidade;
    }

    public void setespecialidade(String especialidade) {
        this.especialidade = especialidade;
    }

    @Override
    public void cadastrar(String nome,int idade) {
        setNome()
        set(idade)
    }

    @Override
    public void exibirDados() {
        System.out.printf("DADOS DO veterinario%n"
                + "nome: %s%nidade: %d%nCPF: %s%ntelefone: %s%n"
                + "código do veterinario: %s%nendereço: %s%n",
                getNome(), getidade(), getCpf(), getTelefone(),
                crmv, especialidade);
    }
}
