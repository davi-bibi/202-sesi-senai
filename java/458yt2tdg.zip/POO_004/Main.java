package POO_004;

public class Main {
    public static void main(String[] args) {
        cliente cliente1 = new cliente(
                "bibi", 16, "0000000000000", "47-990000000",
                "abc-222", "concordia-Sc");
        cliente1.exibirDados();
    }
}
